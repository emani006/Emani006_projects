const dodatki = {
    "ribbon" : {
        "name" : 'лента',
        "value" : 5
    },
    "baloon" : {
        "name" : 'шарики',
        "value" : 10
    },
    "teddy" : {
        "name" : 'мишка',
        "value" : 15
    }
}